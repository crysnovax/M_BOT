# 𝐗𝐀𝐃𝐎𝐍 𝐀𝐈

A modular WhatsApp bot built using Node.js and Baileys — designed as the foundation for my YouTube tutorial series.  
With this base, you can easily add new commands every day and build your own full-featured WhatsApp bot from scratch.

💡 Features:
- Dynamic plugin system (just add .js command files)
- Auto reload (no restart needed)
- Owner & admin permissions
- Organized categories
- System tools and media commands
- Beginner-friendly code for learning

Each episode adds 1–2 new commands so you can follow along and grow your bot step by step — even if you don’t know how to code.

🧠 Need to edit the bot files?  
👉 [Download MT Manager](https://t.me/hectorbotsfiles/83)

👨‍💻 Base Project by [𝐌𝐮𝐬𝐭𝐞𝐪𝐞𝐞𝐦](https://t.me/musteqeem)  
🎥 Tutorials & Upgrades by ** musteqeem **  
🔗 Library: [Baileys by @WhiskeySockets](https://github.com/WhiskeySockets/Baileys)

📺 YouTube: [Hector Manuel](https://youtube.com/@musteqeeml)  
💬 Telegram: [Official Channel](https://t.me/𝐗𝐀𝐃𝐎𝐍 𝐀𝐈)

> “Small daily progress builds big results.” – 𝐅𝐔𝐓𝐔𝐑𝐄 𝐒𝐂𝐈𝐄𝐍𝐓𝐈𝐒𝐓
