import fs from 'fs-extra';
import path from 'path';
import Cerebras from '@cerebras/cerebras_cloud_sdk';

const DATA_DIR = path.join(process.cwd(), 'data', 'ai');
const HISTORY_FILE = path.join(DATA_DIR, 'ai_history.json');
const SETTINGS_FILE = path.join(DATA_DIR, 'ai_settings.json');

const MODELS = {
    '1': 'llama3.1-8b',
    '2': 'llama-3.3-70b',
    '3': 'llama-4-scout-17b-16e-instruct'
};

const DEFAULT_MODEL = MODELS['2'];
const MAX_HISTORY = 20;

let client = null;

function getClient() {
    if (!client) {
        client = new Cerebras({
            apiKey: process.env.CEREBRAS_API_KEY,
            warmTCPConnection: false
        });
    }
    return client;
}

async function ensureDataDir() {
    await fs.ensureDir(DATA_DIR);
}

async function loadSettings() {
    await ensureDataDir();
    try {
        const data = await fs.readJSON(SETTINGS_FILE);
        return data;
    } catch {
        return { model: DEFAULT_MODEL };
    }
}

async function saveSettings(settings) {
    await ensureDataDir();
    await fs.writeJSON(SETTINGS_FILE, settings, { spaces: 2 });
}

async function loadHistory(uid) {
    await ensureDataDir();
    try {
        const all = await fs.readJSON(HISTORY_FILE);
        return all[uid] || [];
    } catch {
        return [];
    }
}

async function saveHistory(uid, history) {
    await ensureDataDir();
    let all = {};
    try { all = await fs.readJSON(HISTORY_FILE); } catch {}
    const trimmed = history.slice(-MAX_HISTORY);
    all[uid] = trimmed;
    await fs.writeJSON(HISTORY_FILE, all, { spaces: 2 });
}

async function resetHistory(uid) {
    await saveHistory(uid, []);
}

async function chat(model, messages) {
    const resp = await getClient().chat.completions.create({ model, messages, stream: false });
    return resp?.choices?.[0]?.message?.content || '';
}

module.exports {
    command: 'ai',
    aliases: ['chatgpt', 'gpt', 'ask'],
    category: 'ai',
    description: 'Chat with Cerebras AI - fast, smart responses with memory',
    usage: 'ai <question>',
    example: 'ai explain quantum computing in simple terms',
    cooldown: 2,
    permissions: ['user'],
    args: false,
    minArgs: 0,

    async execute({ sock, message, args, from, sender }) {
        const body = args.join(' ').trim();
        const uid = sender;

        if (!body) {
            const settings = await loadSettings();
            const history = await loadHistory(uid);
            const modelName = Object.entries(MODELS).find(([, v]) => v === settings.model)?.[1] || DEFAULT_MODEL;
            return await sock.sendMessage(from, {
                text: `AI is ready! Ask me anything.\n\nCurrent model: ${modelName}\nHistory: ${history.length} messages\n\nCommands:\n• ai clear — clear your history\n• ai -set:1 — llama3.1-8b (fast)\n• ai -set:2 — llama-3.3-70b (smart)\n• ai -set:3 — llama-4-scout (latest)`
            }, { quoted: message });
        }

        if (body === 'clear') {
            await resetHistory(uid);
            return await sock.sendMessage(from, { text: 'Chat history cleared.' }, { quoted: message });
        }

        if (body === '-set:1' || body === '-set:2' || body === '-set:3') {
            const num = body.slice(-1);
            const model = MODELS[num];
            await saveSettings({ model });
            return await sock.sendMessage(from, {
                text: `Model changed to: ${model}`
            }, { quoted: message });
        }

        const thinking = await sock.sendMessage(from, { text: 'Thinking...' }, { quoted: message });

        try {
            const settings = await loadSettings();
            const history = await loadHistory(uid);

            history.push({ role: 'user', content: body });

            const response = await chat(settings.model, history);
            const replyText = response || 'No response received.';

            history.push({ role: 'assistant', content: replyText });
            await saveHistory(uid, history);

            await sock.sendMessage(from, { text: replyText, edit: thinking.key });

            if (!global.replyHandlers) global.replyHandlers = {};

            const continueConversation = async (replyText, replyMessage) => {
                const replySender = replyMessage.key.participant || replyMessage.key.remoteJid;
                if (replySender !== sender) return;
                const userText = replyText?.trim();
                if (!userText) return;

                const thinkingMsg = await sock.sendMessage(from, { text: 'Thinking...' }, { quoted: replyMessage });

                try {
                    const currentSettings = await loadSettings();
                    const currentHistory = await loadHistory(uid);
                    currentHistory.push({ role: 'user', content: userText });

                    const aiReply = await chat(currentSettings.model, currentHistory);
                    const aiText = aiReply || 'No response received.';

                    currentHistory.push({ role: 'assistant', content: aiText });
                    await saveHistory(uid, currentHistory);

                    await sock.sendMessage(from, { text: aiText, edit: thinkingMsg.key });
                    global.replyHandlers[thinkingMsg.key.id] = { command: 'ai', handler: continueConversation };
                } catch (err) {
                    await sock.sendMessage(from, { text: 'Error getting response. Try again.', edit: thinkingMsg.key });
                }
            };

            global.replyHandlers[thinking.key.id] = { command: 'ai', handler: continueConversation };

        } catch (err) {
            await sock.sendMessage(from, { text: 'Error connecting to AI. Please try again.', edit: thinking.key });
        }
    }
};
